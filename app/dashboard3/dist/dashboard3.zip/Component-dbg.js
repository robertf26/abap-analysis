sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("dashboard3.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);