sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("dashboard2.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);